import React from 'react';
import WalletBalance from './components/WalletBalance';

const App = () => {
  return (
    <div>
      <h1>Your App</h1>
      <WalletBalance />
    </div>
  );
};

export default App;
